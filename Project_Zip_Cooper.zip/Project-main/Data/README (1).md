# Project
This is a final project for the foundations of data analytics class. It includes nearly a thousand observations of ten different columns: 
  meta score
  user score
  title
  platform
  release date
  details page link
  esrb rating
  developers
  genres
It includes all sorts of Nintendo software, from normal games for Nintendo, to add on software and dlc, listing the data that can be found for all of them- though some of them lack all of the data needed, leaving null values.
Link: https://www.kaggle.com/datasets/mrmorj/nintendo-games-dataset
